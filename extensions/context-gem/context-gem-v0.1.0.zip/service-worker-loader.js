import './assets/service-worker.ts-3wSRNhGw.js';
